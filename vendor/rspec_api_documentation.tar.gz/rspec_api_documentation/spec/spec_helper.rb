require 'rspec_api_documentation'
require 'fakefs/spec_helpers'
require 'rspec/its'
require 'pry'

RSpec.configure do |config|
end
