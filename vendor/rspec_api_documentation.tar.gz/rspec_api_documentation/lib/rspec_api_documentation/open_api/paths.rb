module RspecApiDocumentation
  module OpenApi
    class Paths < Node
      CHILD_CLASS = Path
    end
  end
end
